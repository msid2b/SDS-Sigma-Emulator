//
//  TerminalWindowController.swift
//  Siggy
//
//  Created by MS on 2023-07-04.
//

import Cocoa

class TerminalWindowController: NSWindowController {

    override func windowDidLoad() {
        super.windowDidLoad()
    
        // Implement this method to handle any initialization after your window controller's window has been loaded from its nib file.
    }

}
