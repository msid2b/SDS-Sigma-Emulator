//
//  PanelViewController.swift
//  Siggy
//
//  Created by MS on 2023-01-30.
//

import Cocoa

class MainWindowController: NSViewController, NSWindowDelegate {
    
    var cpuThread: CPU!
    var statusTimer: Timer!
    var panelWindow: NSWindow!
    

}

