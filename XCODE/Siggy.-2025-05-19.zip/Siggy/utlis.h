//
//  utlis.h
//  Siggy
//
//  Created by MS on 2023-03-05.
//

#ifndef utlis_h
#define utlis_h

#include <stdio.h>

#endif /* utlis_h */
