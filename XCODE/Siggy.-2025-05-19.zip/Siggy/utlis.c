//
//  utlis.c
//  Siggy
//
//  Created by MS on 2023-03-05.
//

#include "utlis.h"



