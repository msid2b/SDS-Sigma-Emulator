//
//  VMTabView.swift
//  Siggy
//
//  Created by MS on 2025-02-22.
//

import Cocoa

class VMTabView: NSTabView {
    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
    }
}
